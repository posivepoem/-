var app = document.getElementById('app');
var spans = app.getElementsByTagName('span');
var ps = app.getElementsByTagName('p');
for(var i = 0, len = spans.length; i < len; i++) {
	spans[i].index = i;
	spans[i].onclick = function() {
		for(var j = 0; j < len; j++) {
			spans[j].className = '';
		}
		spans[this.index].className = 'choose';
		for(var k = 0, klen = ps.length; k < klen; k++) {
			ps[k].className = '';
		}
		ps[this.index].className = 'choose';
	}
}
 var btns = $('.action');
 var box = $('.text');
 btns.eq(0).click(function(){
 	box.slideDown(function(){
 		box.css({backgroundColor: 'white'})
 	});
 })
   btns.eq(1).click(function(){
   	box.slideUp();
   })
   btns.eq(1).click(function(){
   	box.slideToggle();
   })
$('.find').click(function(){
	$('.bodyer-moddule').html('<h1><a href="随笔.html">随笔</a></h1>');
})
//$('.find').mousemove(function(){
//	$('.mourse').animate({right: 150,top: 20}, 300,function(){
//		$('.mourse').css({display: 'none'})
//	});
//	$('.imgs').animate({left: 1000,top: 60}, 800);
// 
//})
//
//$('li').each(function(index){
//	$(this).css('left', 180*index)
//})
//$('li').mouseenter(function(){
//	var index= $(this).index();
////	$('li:lt('+ (index+i) +')').each(function(i){
////			$(this).css( 'left', 80*i);
////	})
//    $(this).prevAll().each(function(i){
//    	  $(this).animate({'left': 85*(index-i-1)},500)
//    })
//    $(this).animate({'left': 85*index},400)
//     $(this).nextAll().each(function(i){
//    	  $(this).animate({'left': 85*(i+index)+300},200);
//    })
////     
////   $('li:gt('+ index +')').each(function(i){
////   	$(this).css( 'left', 80*( i+index)+300);
////   })
//
//})
var $contents=$('.contents');
var index=0;
var $btns = $('.btns span');
var timebar;
function startInterval(){
	timebar=setInterval(function(){
	index++;
	if(index>=4)
	{
		index=0;
	}
	change();//判断图片是否播完，最后一张播完继续播第一张
//	$contents.animate({left: -index*800},700,function(){
//		$btns
//		  .eq(index).addClass('chooses')
//		  .siblings().removeClass('chooses')
//	})

},5000)
}
startInterval()
function change(fn) {
	$contents.animate({left: -index*900},700,function(){
		if(index==0){
     	index=4;
     	$('.contents').css('left', -900*index);
     }
     else if(index==5){
     	index=1;
     	$('.contents').css('left',-900*index);
     }/**/
	
		$btns
		  .eq(index-1).addClass('chooses')
		  .siblings().removeClass('chooses')
		  //
		  //if(fn){
//	fn();
//}

fn&&fn();//优化
   })    
}
$btns.click(function(){
	clearInterval(timebar)
	index=$(this).index()+1
	
//	change(function(){
//		startInterval()
//	});
	change(startInterval)//优化
})
$('.next').click(function(){
	clearInterval(timebar)
	index++;
	if(index>=6)
	{
		index=0;
	}
	change(startInterval)
	
})
$('.prev').click(function(){
	clearInterval(timebar)
	index--;
	if(index<0)
	{
		index=4;
	}
	change(startInterval)
})
//var $img = $('.exchange img');
//var $btns=$('.btns span')
//var $contents=$('.contents')
//var id=0;
//var str=''
//
//for (var i=0;i<3;i++) {
//	
////	str += '<div class="row">'
//	for (var j=0; j<5;j++) {
//		str += '<div class="col"></div>';
////		row.append(col);
//	}
////	str+='</div>';
//}
//$contents.html(str)
//$contents.find('.col')
// .each(function(index){
//	$(this).css({
//		backgroundPositionX: -160 *(index % 4),
//		backgroundPositionY: -25 *parseInt(index / 4),
//		top: 25 *parseInt(index / 4),
//		left: 160 *(index % 4)
//	})
//})
//$contents.find('.col').css({
//	backgroundImg: 'url(img/'+ id +'.jpg)',
//	width:0,
//	height:0,
//	opacity:0
//}).animate({
//	width: 160,
//	height:160,
//	opacity:1
//},1000)
//
//var number = 0;
//function demo(){
//	console.log(++number);
//}
////var timebar;
////window.onscroll=function() {
////	throttle(demo)
////}
////function throttle(fn){//封装的防抖函数
////clearTimeout(fn.__timebar)
////fn.__timebar=setTimeout(fn,200)
//// }
//var lock =false
//window.onscroll=function(){
//	time(demo);
//}
//function time(fn){
//	if(fn._lock)
//	{
//		return
//	}
//	
//	fn._lock= true;
//	fn()
//	setTimeout(function(){
//		//解除封锁
//		fn._lock=false
//	},4000)
//}
 
//$('#app').highcharts({
//	title:{
//		text:'出勤人数表'
//		
//	},
//	xAxis:{
//		title:{
//			text: '星期'
//		}
//	},
//		series:[{
//			data: [21,43,54,32,12,12],
//		
//		}],
//		series:[{
//			data: [21,65,54,45,12,23]}]
//})

